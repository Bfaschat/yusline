# Short URLs Bot [![Bot](https://img.shields.io/badge/Telegram-@ShortURLsBot-red.svg?style=flat)][Bot]
**Short URLs Bot** it's a **Telegram bot** for shorting URLs

### Functionality and utilization
The bot is attainable on **Telegram** by searching `@ShortURLsBot` in search bar or type in any chat `@ShortURLsBot URL`. 

### Installation
For installing this bot on your VPS Linux Ubuntu, you must perform this commands: (python 3.5 required)

    $ python3 -m pip install botogram
    $ git clone https://www.github.com/MarcoBuster/ShortURLsBot.git && cd ShortURLsBot.git
    $ python3 "Bot.py"

> Warning! Edit CONFIG file before starting the bot!

### License and credits
The bot is developed by [Marco] and released under [MIT license][MIT]

[Bot]: https://telegram.me/ShortURLsBot
[Marco]: https://www.github.com/MarcoBuster
[MIT]: https://opensource.org/licenses/MIT
